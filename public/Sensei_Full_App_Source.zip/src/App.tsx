import React, { useState, useEffect } from 'react';
import { TabType, UserStats } from './types';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './screens/HomeScreen';
import { LessonScreen } from './screens/LessonScreen';
import { VoiceCoachScreen } from './screens/VoiceCoachScreen';
import { AlphabetScreen } from './screens/AlphabetScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { GitHubApkModal } from './screens/GitHubApkModal';
import { requestNotificationPermission, startNotificationScheduler } from './utils/notifications';
import { Bell, X } from 'lucide-react';

export function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [activeLesson, setActiveLesson] = useState<{ unitId: string; levelId: string } | null>(null);
  const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);
  const [showNotificationPrompt, setShowNotificationPrompt] = useState(false);

  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem('sensei_user_stats');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { }
    }
    return {
      xp: 280,
      streak: 4,
      gems: 150,
      hearts: 5,
      completedLessons: ['l1-1', 'l1-2'],
      level: 2,
      selectedLanguage: 'en',
      dailyGoal: 50,
      todayMinutes: 12
    };
  });

  useEffect(() => {
    localStorage.setItem('sensei_user_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    startNotificationScheduler();

    // Check if notification permission prompt has been shown
    const hasPrompted = localStorage.getItem('sensei_notification_prompted');
    if (!hasPrompted && typeof Notification !== 'undefined' && Notification.permission !== 'granted') {
      const timer = setTimeout(() => setShowNotificationPrompt(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleEnableNotifications = async () => {
    localStorage.setItem('sensei_notification_prompted', 'true');
    setShowNotificationPrompt(false);
    await requestNotificationPermission();
  };

  const handleDismissNotifications = () => {
    localStorage.setItem('sensei_notification_prompted', 'true');
    setShowNotificationPrompt(false);
  };

  const handleStartLesson = (unitId: string, levelId: string) => {
    setActiveLesson({ unitId, levelId });
  };

  const handleFinishLesson = (xpEarned: number) => {
    if (activeLesson) {
      setStats(prev => ({
        ...prev,
        xp: prev.xp + xpEarned,
        gems: prev.gems + 10,
        completedLessons: prev.completedLessons.includes(activeLesson.levelId)
          ? prev.completedLessons
          : [...prev.completedLessons, activeLesson.levelId]
      }));
    }
    setActiveLesson(null);
  };

  const handleSelectLanguage = () => {
    const languages: ('en' | 'de' | 'es' | 'fr' | 'ja' | 'ru')[] = ['en', 'de', 'es', 'fr', 'ja', 'ru'];
    const nextIdx = (languages.indexOf(stats.selectedLanguage) + 1) % languages.length;
    setStats(prev => ({ ...prev, selectedLanguage: languages[nextIdx] }));
  };

  if (activeLesson) {
    return (
      <LessonScreen
        unitId={activeLesson.unitId}
        levelId={activeLesson.levelId}
        onFinish={handleFinishLesson}
        onExit={() => setActiveLesson(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header */}
      <TopBar
        stats={stats}
        onOpenGitHubModal={() => setIsGitHubModalOpen(true)}
        onSelectLanguage={handleSelectLanguage}
      />

      {/* Daily Notification Permission Banner */}
      {showNotificationPrompt && (
        <div className="max-w-md mx-auto w-full px-4 pt-3">
          <div className="bg-gradient-to-r from-emerald-900/90 to-teal-900/90 border border-emerald-500/50 p-4 rounded-2xl shadow-xl flex items-start gap-3 relative animate-bounce-subtle">
            <div className="p-2 bg-emerald-500 text-slate-950 rounded-xl mt-0.5">
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1 text-xs">
              <h4 className="font-bold text-white text-sm">Günlük Hatırlatıcıları Aç</h4>
              <p className="text-emerald-200 mt-1 leading-relaxed">
                Sensei sana sabah (10:00), öğlen (14:00) ve akşam (20:30) motivasyon bildirimleri göndersin mi?
              </p>
              <div className="flex items-center gap-2 mt-3">
                <button
                  onClick={handleEnableNotifications}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg transition text-xs shadow-md"
                >
                  Evet, İzin Ver
                </button>
                <button
                  onClick={handleDismissNotifications}
                  className="text-slate-300 hover:text-white px-2 py-1.5 transition text-xs"
                >
                  Daha Sonra
                </button>
              </div>
            </div>
            <button
              onClick={handleDismissNotifications}
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-2xl mx-auto w-full">
        {currentTab === 'home' && (
          <HomeScreen
            stats={stats}
            onStartLesson={handleStartLesson}
            onOpenGitHubModal={() => setIsGitHubModalOpen(true)}
          />
        )}
        {currentTab === 'voice' && <VoiceCoachScreen />}
        {currentTab === 'alphabet' && <AlphabetScreen selectedLanguage={stats.selectedLanguage} />}
        {currentTab === 'profile' && (
          <ProfileScreen
            stats={stats}
            onOpenGitHubModal={() => setIsGitHubModalOpen(true)}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} />

      {/* GitHub APK Builder Modal */}
      <GitHubApkModal
        isOpen={isGitHubModalOpen}
        onClose={() => setIsGitHubModalOpen(false)}
      />
    </div>
  );
}

export default App;
